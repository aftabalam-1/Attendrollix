<?php
// ============================================================
//  includes/db.php
//  Database connection, response helpers, and auth guard.
// ============================================================

// ── Database credentials ──────────────────────────────────
// XAMPP default  : DB_PASS = ''   (empty string)
// Laragon default: DB_PASS = 'root'
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');        // Change to 'root' if using Laragon
define('DB_NAME', 'attendrollix');

// ── PDO singleton connection ──────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = sprintf(
                'mysql:host=%s;dbname=%s;charset=utf8mb4',
                DB_HOST, DB_NAME
            );
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            jsonError('Database connection failed. Check DB credentials in includes/db.php', 500);
        }
    }
    return $pdo;
}

// ── JSON response helpers ─────────────────────────────────
function jsonSuccess(mixed $data = [], string $message = 'Success'): never {
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}

function jsonError(string $message, int $code = 400): never {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $message, 'data' => null]);
    exit;
}

// ── CORS + Content-Type headers ───────────────────────────
function setCorsHeaders(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
    header('Content-Type: application/json');
}

// ── Session authentication guard ─────────────────────────
// Call this at the top of any API file that requires login.
function requireAuth(): array {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['college_id'])) {
        jsonError('Not authenticated. Please log in first.', 401);
    }
    return [
        'college_id' => (int) $_SESSION['college_id'],
        'email'      => $_SESSION['college_email'],
        'name'       => $_SESSION['college_name'],
    ];
}

// ── Parse JSON request body ───────────────────────────────
function getBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}

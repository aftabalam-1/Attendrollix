-- ============================================================
--  Attendrollix — Database Setup
--  Compatible with: XAMPP / Laragon (MariaDB / MySQL)
--
--  INSTRUCTIONS:
--  1. Open phpMyAdmin → click the "SQL" tab
--  2. Paste the entire contents of this file
--  3. Click "Go"
-- ============================================================

DROP DATABASE IF EXISTS attendrollix;

CREATE DATABASE attendrollix
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE attendrollix;

-- ── Table: colleges ───────────────────────────────────────
-- Stores one record per registered college/institution.
-- The email column is used as the login identifier.
CREATE TABLE colleges (
  id          INT           AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150)  NOT NULL,
  email       VARCHAR(150)  NOT NULL UNIQUE,   -- used as login ID
  password    VARCHAR(255)  NOT NULL,           -- bcrypt hashed
  location    VARCHAR(200)  DEFAULT '',
  board       VARCHAR(200)  DEFAULT '',
  phone       VARCHAR(20)   DEFAULT '',
  created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Table: courses ────────────────────────────────────────
-- Each college can have multiple courses (e.g. B.Sc, BCA).
CREATE TABLE courses (
  id           INT           AUTO_INCREMENT PRIMARY KEY,
  college_id   INT           NOT NULL,
  course_key   VARCHAR(30)   NOT NULL,          -- short code e.g. 'bsc', 'bca'
  label        VARCHAR(100)  NOT NULL,           -- display name e.g. 'B.Sc'
  color        VARCHAR(10)   DEFAULT '#3b82f6',  -- hex color for UI
  created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_college_course (college_id, course_key),
  FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Table: students ───────────────────────────────────────
-- Each student belongs to one college and one course.
-- A unique QR code is auto-generated when the student is added.
CREATE TABLE students (
  id          INT           AUTO_INCREMENT PRIMARY KEY,
  college_id  INT           NOT NULL,
  course_id   INT           NOT NULL,
  name        VARCHAR(150)  NOT NULL,
  roll        VARCHAR(50)   NOT NULL,
  phone       VARCHAR(20)   DEFAULT '',
  email       VARCHAR(150)  DEFAULT '',
  qr_code     VARCHAR(60)   NOT NULL UNIQUE,    -- format: QR-S{id}-XXXXXXXX
  created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Table: attendance ─────────────────────────────────────
-- One record per student per date. Duplicate entries are blocked
-- by the unique key on (student_id, att_date).
CREATE TABLE attendance (
  id           INT   AUTO_INCREMENT PRIMARY KEY,
  student_id   INT   NOT NULL,
  college_id   INT   NOT NULL,
  att_date     DATE  NOT NULL,
  status       ENUM('present', 'absent', 'late') NOT NULL,
  marked_time  TIME  DEFAULT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_student_date (student_id, att_date),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Demo college ──────────────────────────────────────────
-- Login: admin@tmv.edu / tmv@123
-- Password hash is bcrypt of 'tmv@123'
INSERT INTO colleges (name, email, password, location, board, phone)
VALUES (
  'TMV College',
  'admin@tmv.edu',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  'Pune, Maharashtra',
  'Savitribai Phule Pune University',
  '020-12345678'
);

-- Demo courses for the demo college
SET @cid = LAST_INSERT_ID();
INSERT INTO courses (college_id, course_key, label, color) VALUES
  (@cid, 'bsc',  'B.Sc',  '#3b82f6'),
  (@cid, 'bcom', 'B.Com', '#f59e0b'),
  (@cid, 'bca',  'BCA',   '#10b981'),
  (@cid, 'ba',   'B.A',   '#ef4444'),
  (@cid, 'bba',  'BBA',   '#8b5cf6');

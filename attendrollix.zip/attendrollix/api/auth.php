<?php
// ============================================================
//  api/auth.php  —  Authentication
//
//  POST /api/auth.php?action=register  Register a new college
//  POST /api/auth.php?action=login     Log in
//  POST /api/auth.php?action=logout    Log out
//  GET  /api/auth.php?action=me        Get current session info
// ============================================================

require_once __DIR__ . '/../includes/db.php';
setCorsHeaders();

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$action = $_GET['action'] ?? '';

match ($action) {
    'register' => handleRegister(),
    'login'    => handleLogin(),
    'logout'   => handleLogout(),
    'me'       => handleMe(),
    default    => jsonError('Unknown action.', 404),
};

// ── Register ──────────────────────────────────────────────
function handleRegister(): never {
    $body = getBody();

    $name     = trim($body['name']     ?? '');
    $email    = strtolower(trim($body['email'] ?? ''));
    $password = $body['password'] ?? '';
    $location = trim($body['location'] ?? '');
    $board    = trim($body['board']    ?? '');
    $phone    = trim($body['phone']    ?? '');

    // Validation
    if (!$name)     jsonError('College name is required.');
    if (!$email)    jsonError('Email address is required.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonError('Invalid email format.');
    if (strlen($password) < 6) jsonError('Password must be at least 6 characters.');

    $db = getDB();

    // Check for duplicate email
    $stmt = $db->prepare('SELECT id FROM colleges WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonError('This email is already registered. Please log in instead.');
    }

    // Store bcrypt-hashed password
    $hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $db->prepare(
        'INSERT INTO colleges (name, email, password, location, board, phone)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$name, $email, $hash, $location, $board, $phone]);
    $collegeId = (int) $db->lastInsertId();

    // Add default courses for the new college
    $defaults = [
        ['bsc',  'B.Sc',  '#3b82f6'],
        ['bcom', 'B.Com', '#f59e0b'],
        ['bca',  'BCA',   '#10b981'],
        ['ba',   'B.A',   '#ef4444'],
        ['bba',  'BBA',   '#8b5cf6'],
    ];
    $cs = $db->prepare(
        'INSERT IGNORE INTO courses (college_id, course_key, label, color)
         VALUES (?, ?, ?, ?)'
    );
    foreach ($defaults as [$key, $label, $color]) {
        $cs->execute([$collegeId, $key, $label, $color]);
    }

    jsonSuccess([
        'college_id' => $collegeId,
        'email'      => $email,
        'name'       => $name,
    ], 'Registration successful! You can now log in with your email and password.');
}

// ── Login ─────────────────────────────────────────────────
function handleLogin(): never {
    $body     = getBody();
    $email    = strtolower(trim($body['email'] ?? ''));
    $password = $body['password'] ?? '';

    if (!$email || !$password) {
        jsonError('Email and password are required.');
    }

    $db   = getDB();
    $stmt = $db->prepare('SELECT * FROM colleges WHERE email = ?');
    $stmt->execute([$email]);
    $college = $stmt->fetch();

    if (!$college || !password_verify($password, $college['password'])) {
        jsonError('Invalid email or password. Please try again.');
    }

    // Store session
    $_SESSION['college_id']    = $college['id'];
    $_SESSION['college_email'] = $college['email'];
    $_SESSION['college_name']  = $college['name'];

    jsonSuccess([
        'college_id' => $college['id'],
        'email'      => $college['email'],
        'name'       => $college['name'],
        'location'   => $college['location'],
        'board'      => $college['board'],
        'phone'      => $college['phone'],
    ], 'Login successful. Welcome back!');
}

// ── Logout ────────────────────────────────────────────────
function handleLogout(): never {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION = [];
    session_destroy();
    jsonSuccess([], 'You have been logged out successfully.');
}

// ── Me (session check) ────────────────────────────────────
function handleMe(): never {
    if (empty($_SESSION['college_id'])) {
        jsonError('No active session. Please log in.', 401);
    }
    $db   = getDB();
    $stmt = $db->prepare(
        'SELECT id, name, email, location, board, phone FROM colleges WHERE id = ?'
    );
    $stmt->execute([$_SESSION['college_id']]);
    $college = $stmt->fetch();
    if (!$college) jsonError('College record not found.', 404);
    jsonSuccess($college);
}
